  var subjectObject = {
    "Front-end": {
      "HTML": ["Links", "Images", "Tables", "Lists"],
      "CSS": ["Borders", "Margins", "Backgrounds", "Float"],
      "JavaScript": ["Variables", "Operators", "Functions", "Conditions"]
    },
    "Back-end": {
      "PHP": ["Variables", "Strings", "Arrays"],
      "SQL": ["SELECT", "UPDATE", "DELETE"]
    }
  }
  window.onload = function() {
    var subjectSel = document.getElementById("author");
    var topicSel = document.getElementById("participant");
    var chapterSel = document.getElementById("student");
    for (var x in subjectObject) {
      subjectSel.options[subjectSel.options.length] = new Option(x, x);
    }
    subjectSel.onchange = function() {
      //empty Chapters- and Topics- dropdowns
      chapterSel.length = 1;
      topicSel.length = 1;
      //display correct values
      for (var y in subjectObject[this.value]) {
        topicSel.options[topicSel.options.length] = new Option(y, y);
      }
    }
    topicSel.onchange = function() {
      //empty Chapters dropdown
      chapterSel.length = 1;
      //display correct values
      var z = subjectObject[subjectSel.value][this.value];
      for (var i = 0; i < z.length; i++) {
        chapterSel.options[chapterSel.options.length] = new Option(z[i], z[i]);
      }
    }
  }
  


	function GEEKFORGEEKS() {
		var name = document.forms["RegForm"]["fullname"];
		var email = document.forms["RegForm"]["email"];
		var phone = document.forms["RegForm"]["phn"];
		var organization = document.forms["RegForm"]["organization"];
		var discount = document.forms["RegForm"]["discount"];

		if (name.value == "") {
			window.alert("Please enter your name.");
			name.focus();
			return false;
		}

		if (organization.value == "") {
			window.alert("Please enter your organization.");
			address.focus();
			return false;
		}

		if (email.value == "") {
			window.alert(
			"Please enter a valid e-mail address.");
			email.focus();
			return false;
		}

		if (phone.value == "") {
			window.alert(
			"Please enter your telephone number.");
			phone.focus();
			return false;
		}

		if (discount.selectedIndex < 1) {
			alert("Please enter a valid discount code.");
			what.focus();
			return false;
		}

		return true;
	}


  
  

  